require("dotenv").config();

const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// ✅ DB CONNECTION
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root123",
  database: "student_db"
});

db.connect((err) => {
  if (err) {
    console.log("DB Error ❌", err);
  } else {
    console.log("MySQL Connected ✅");
  }
});

// ✅ ROOT ROUTE
app.get("/", (req, res) => {
  res.send("Server + MySQL working ✅");
});

// ✅ TEST DB
app.get("/test-db", (req, res) => {
  db.query("SELECT * FROM students1", (err, result) => {
    if (err) return res.status(500).send("DB Error ❌");
    res.json(result);
  });
});

// ✅ CREATE STUDENT
app.post("/api/students", (req, res) => {
  const { name, email, course } = req.body;

  if (!name || !email || !course) {
    return res.status(400).send("All fields required ❌");
  }

  const sql = "INSERT INTO students1 (name, email, course) VALUES (?, ?, ?)";

  db.query(sql, [name, email, course], (err, result) => {
    if (err) {
      console.log(err);
      return res.status(500).send("Insert error ❌");
    }
    res.send("Student added ✅");
  });
});

// ✅ GET STUDENTS (SEARCH + SORT)
app.get("/api/students", (req, res) => {
  const search = req.query.search || "";

  const sql = `
    SELECT * FROM students1
    WHERE name LIKE ? OR email LIKE ?
    ORDER BY name ASC
  `;

  db.query(sql, [`%${search}%`, `%${search}%`], (err, result) => {
    if (err) {
      console.log(err);
      return res.status(500).send("Fetch error ❌");
    }
    res.json(result);
  });
});

// ✅ UPDATE STUDENT
app.put("/api/students/:id", (req, res) => {
  const { name, email, course } = req.body;
  const { id } = req.params;

  const sql = "UPDATE students1 SET name=?, email=?, course=? WHERE id=?";

  db.query(sql, [name, email, course, id], (err, result) => {
    if (err) {
      console.log(err);
      return res.status(500).send("Update error ❌");
    }

    if (result.affectedRows === 0) {
      return res.send("ID not found ❌");
    }

    res.send("Student updated ✏️");
  });
});

// ✅ DELETE STUDENT
app.delete("/api/students/:id", (req, res) => {
  const { id } = req.params;

  console.log("Deleting ID:", id);

  db.query("DELETE FROM students1 WHERE id=?", [id], (err, result) => {
    if (err) {
      console.log(err);
      return res.status(500).send("Delete error ❌");
    }

    console.log("Affected rows:", result.affectedRows);

    if (result.affectedRows === 0) {
      return res.send("ID not found ❌");
    }

    res.send("Student deleted ✅");
  });
});

// ✅ START SERVER
app.listen(5000, () => {
  console.log("Server running on port 5000");
});